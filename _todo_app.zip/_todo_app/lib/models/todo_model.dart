import 'package:equatable/equatable.dart';

class Todo extends Equatable {
  final String id;
  final String title;
  final String description;
  final DateTime date;
  final bool isDone;
  final String priority; // low, medium, high
  // BARU: Field untuk menyimpan nama kontak (opsional)
  final String? contactName; 

  const Todo({
    required this.id,
    required this.title,
    required this.description,
    required this.date,
    this.isDone = false,
    this.priority = 'medium',
    this.contactName, // BARU
  });

  // Constructor factory untuk membuat objek Todo dari Map (JSON)
  factory Todo.fromJson(Map<String, dynamic> json) {
    return Todo(
      id: json['id'] as String,
      title: json['title'] as String,
      description: json['description'] as String,
      date: DateTime.parse(json['date'] as String), 
      isDone: json['isDone'] as bool,
      priority: json['priority'] as String,
      contactName: json['contactName'] as String?, 
    );
  }

  // Method untuk mengonversi objek Todo ke Map (JSON)
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'description': description,
      'date': date.toIso8601String(), 
      'isDone': isDone,
      'priority': priority,
      'contactName': contactName, 
    };
  }

  Todo copyWith({
    String? id,
    String? title,
    String? description,
    DateTime? date,
    bool? isDone,
    String? priority,
    String? contactName, // BARU
  }) {
    return Todo(
      id: id ?? this.id,
      title: title ?? this.title,
      description: description ?? this.description,
      date: date ?? this.date,
      isDone: isDone ?? this.isDone,
      priority: priority ?? this.priority,
      contactName: contactName ?? this.contactName, // BARU
    );
  }

  @override
  List<Object?> get props => [id, title, description, date, isDone, priority, contactName];
}
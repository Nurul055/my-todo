import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../blocs/todo_cubit.dart';
import '../models/todo_model.dart';
import '../widgets/todo_card.dart';
import 'todo_detail_page.dart';
import 'todo_grid_page.dart';

class TodoHomePage extends StatefulWidget {
  const TodoHomePage({super.key});

  @override
  State<TodoHomePage> createState() => _TodoHomePageState();
}

class _TodoHomePageState extends State<TodoHomePage> {
  final TextEditingController titleController = TextEditingController();
  final TextEditingController descController = TextEditingController();
  // BARU: Controller untuk input nama kontak
  final TextEditingController contactController = TextEditingController(); 
  String priority = 'medium';

  void _addTodoDialog(BuildContext context) {
    // FIX BUG: Gunakan variabel lokal untuk prioritas
    String localPriority = priority; 
    
    showDialog(
      context: context,
      // FIX BUG: Menggunakan StatefulBuilder untuk manajemen state lokal dialog
      builder: (dialogContext) => StatefulBuilder(
        builder: (statefulContext, localSetState) {
          return AlertDialog(
            title: const Text('Tambah Tugas'),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(controller: titleController, decoration: const InputDecoration(labelText: 'Judul')),
                TextField(controller: descController, decoration: const InputDecoration(labelText: 'Deskripsi')),
                // BARU: Input Nama Kontak
                TextField(controller: contactController, decoration: const InputDecoration(labelText: 'Nama Kontak (Opsional)')),
                
                DropdownButtonFormField<String>(
                  value: localPriority, 
                  items: const [
                    DropdownMenuItem(value: 'low', child: Text('Low')),
                    DropdownMenuItem(value: 'medium', child: Text('Medium')),
                    DropdownMenuItem(value: 'high', child: Text('High')),
                  ],
                  onChanged: (value) => localSetState(() => localPriority = value!), // Gunakan localSetState
                ),
              ],
            ),
            actions: [
              TextButton(onPressed: () => Navigator.pop(statefulContext), child: const Text('Batal')),
              ElevatedButton(
                onPressed: () {
                  if (titleController.text.isNotEmpty) {
                    context.read<TodoCubit>().addTodo(
                        titleController.text,
                        descController.text,
                        localPriority,
                        // BARU: Kirim contactName (argumen ke-4)
                        contactController.text.isEmpty ? null : contactController.text, 
                      );
                    titleController.clear();
                    descController.clear();
                    contactController.clear(); 
                    Navigator.pop(statefulContext);
                  }
                },
                child: const Text('Simpan'),
              ),
            ],
          );
        },
      ),
    );
  }

  // BARU: Widget pembantu untuk menampilkan item statistik
  Widget _statItem(String label, int count, Color color) {
    return Column(
      children: [
        Text(
          label,
          style: TextStyle(color: color, fontWeight: FontWeight.w600),
        ),
        Text(
          count.toString(),
          style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: color),
        ),
      ],
    );
  }

  // BARU: Widget untuk menampilkan kartu statistik
  Widget _buildStatisticsCard(BuildContext context, int total, int completed, int uncompleted) {
    return Card(
      margin: const EdgeInsets.all(8.0),
      color: Theme.of(context).colorScheme.surfaceVariant, // Warna background kartu
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              '📊 Statistik Tugas',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _statItem('Total Data', total, Colors.blue), 
                _statItem('Selesai', completed, Colors.green),
                _statItem('Belum Selesai', uncompleted, Colors.red),
              ],
            ),
          ],
        ),
      ),
    );
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Advanced To-Do List'),
        actions: [
          IconButton(
            icon: const Icon(Icons.grid_view),
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const TodoGridPage()),
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _addTodoDialog(context),
        child: const Icon(Icons.add),
      ),
      // BlocBuilder kini mengembalikan Column untuk statistik dan daftar
      body: BlocBuilder<TodoCubit, List<Todo>>(
        builder: (context, todos) {
          final cubit = context.read<TodoCubit>(); // Ambil Cubit untuk akses getters
          
          return Column(
            children: [
              // BARU: Tampilkan Kartu Statistik
              _buildStatisticsCard(
                context, 
                cubit.totalCount, 
                cubit.completedCount, 
                cubit.uncompletedCount
              ),
              const Divider(height: 1),

              // Daftar Tugas
              Expanded(
                child: todos.isEmpty
                    ? const Center(child: Text('Belum ada tugas'))
                    : ListView.builder(
                        padding: const EdgeInsets.all(12),
                        itemCount: todos.length,
                        itemBuilder: (context, index) {
                          final todo = todos[index];
                          // Catatan: Pastikan Anda memperbarui TodoCard 
                          // agar dapat menampilkan todo.contactName jika ada.
                          return TodoCard(
                            todo: todo,
                            onTap: () => Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => TodoDetailPage(todo: todo),
                              ),
                            ),
                            onDelete: () =>
                                context.read<TodoCubit>().removeTodo(todo.id),
                            onToggle: () =>
                                context.read<TodoCubit>().toggleTodo(todo.id),
                          );
                        },
                      ),
              ),
            ],
          );
        },
      ),
    );
  }
}
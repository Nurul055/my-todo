import 'package:bloc/bloc.dart';
import '../models/todo_model.dart';

class TodoCubit extends Cubit<List<Todo>> {
  TodoCubit() : super([]);

  // MODIFIKASI: Menerima contactName sebagai argumen ke-4
  void addTodo(String title, String description, String priority, String? contactName) {
    final newTodo = Todo(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      title: title,
      description: description,
      date: DateTime.now(),
      priority: priority,
      contactName: contactName, // BARU: Menyimpan contactName
    );
    emit([...state, newTodo]);
  }

  void toggleTodo(String id) {
    emit(state.map((todo) {
      if (todo.id == id) {
        return todo.copyWith(isDone: !todo.isDone); 
      }
      return todo;
    }).toList());
  }

  void removeTodo(String id) {
    emit(state.where((todo) => todo.id != id).toList());
  }

  // BARU: Getters untuk Statistik Tugas
  
  /// Jumlah total semua tugas.
  int get totalCount => state.length;
  
  /// Jumlah tugas yang sudah selesai.
  int get completedCount => state.where((todo) => todo.isDone).length;
  
  /// Jumlah tugas yang belum selesai.
  int get uncompletedCount => state.where((todo) => !todo.isDone).length;
}